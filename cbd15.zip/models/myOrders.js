const { Schema, model } = require("mongoose");

const myOrders = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    myOrders:[]
  }
);

module.exports = model("myOrders", myOrders);

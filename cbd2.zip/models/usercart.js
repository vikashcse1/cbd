const { Schema, model } = require("mongoose");

const usercart = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    products:[]
  },
);

// const usercart = new Schema(
//   {
//     email: {
//       type: String,
//       required: true
//     },
//     products:[]
//   },
// );

module.exports = model("usercart", usercart);

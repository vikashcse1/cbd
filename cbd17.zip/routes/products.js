const router = require("express").Router();
const products = require("../models/products");
const cors = require("cors");
const multer = require('multer');


//storage startegy
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
});
//file filter
const fileFilter = (req, file, cb) => {
    //reject file
    if (file.mimetype === 'image/jpg' ||file.mimetype === 'image/jpeg'||file.mimetype === 'image/png') {
        cb(null, true);
    } 
    else{
    cb(new Error('Message wrong file type.'), false);
    }
}

const upload = multer({ 
    storage: storage ,
    fileFilter:fileFilter
});



//imorting function product
const {
    insert_product,
    get_products,
    delete_product,
    CreateBanner,
    getBanner,
    deleteBanner,
    search
} = require("../utils/products");


// inserting a product

router.post("/insert_products", upload.single('productimage'), async (req, res) => { 
    console.log(req.file==undefined)

    var Image=""
    //console.log(req.file.destination+req.file.originalname)
    if(!req.file){
        Image=String(req.protocol+"://"+req.hostname+":5000/uploads/dummy.jpg")
    }
    else{
        Image=String(req.protocol+"://"+req.hostname+":5000/"+req.file.destination+req.file.originalname)
        
    }
        
    await insert_product(req.body, Image,res);
    res.status(202)
});

// Create Banners Banner
router.post("/banner", upload.single('banner'), async (req, res) => {
    await CreateBanner(req,res);
});

router.post("/deleteBanner",async (req,res)=>{
    await deleteBanner(req,res)
})


//Get all Banner from db
router.get('/banners',async (req,res,next)=>{
    await getBanner(res)
})

// Delet Product 
router.post("/delete_product",async(req,res,next)=>{
    //console.log(req.body)
    await delete_product(req.body.id,res)
})

//Get all Product from db
router.get('/get_products',async (req,res,next)=>{
    await get_products(res)
})


router.post('/search',async (req,res)=>{
    await search(req,res)
})


router.get("/newArrivals",async (req,res)=>{
    await products.find((err,docs)=>{
        if(!err){
            res.send(docs)
        }
        else{
            res.send(err)
        }
    })
  })



module.exports = router;




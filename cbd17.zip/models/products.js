const { Schema, model } = require("mongoose");

const products = new Schema(
  {
 
    product_name: {
      type: String,
      required: true
    },
    product_id: {
      type: String,

    },
    price: {
      type: Number,
      required: true
    },
    sale_price: {
      type: Number,
    },
    category: {
      type: String,
      required: true
    },
    featured:{
        type:Boolean
    },
    product_sd:{
        type:String,

    },
    product_ld:{
        type:String,
 
    },
    image:{
      type:String,
      require:true
    },
    quantity:{
      type:Number,
      require:true
    },
    status:{
      type: Boolean,
      required: true
    },
    discount:{
      type:String
    }

  },
  { timestamps: true }
);
products.index({'$**': 'text'});

module.exports = model("products", products);

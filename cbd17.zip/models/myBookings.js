const { Schema, model } = require("mongoose");
const moment = require('moment');
const { v4: uuidv4 } = require('uuid');


const booking = new Schema(
  {
    
    email: {
      type: String,
      unique: true
    },
    bookings: [{
      bid:{ type: String, required: true},
      product_name: {
        type: String,
        required: true
      },
      product_id: {
        type: String,

      },
      price: {
        type: Number,
        required: true
      },
      sale_price: {
        type: Number,
      },
      category: {
        type: String,

      },
      product_sd: {
        type: String,

      },
      product_ld: {
        type: String,

      },
      image: {
        type: String,
        require: true
      },
      quantity: {
        type: Number,
        require: true
      },
      discount: {
        type: String
      },
      status: {
        type: String,
        default: '1'
      },
      subTotal: {

      },
      date: { type: Date, required: true, default: Date.now() },
      address: []
    }],

  },
  { timestamps: true }
);

module.exports = model("booking", booking);

const router = require("express").Router();
const User = require("../models/User");
const usercart = require("../models/usercart");
const products = require("../models/products")
const cors = require("cors");
const ObjectId  = require("mongoose")

// Bring in the User Registration function
const {
  userAuth,
  userLogin,
  checkRole,
  userRegister,
  serializeUser,
  getUserList,
  resetPassword,
  verify,
  changePassword,
  forgetPassword,
  notifications,
  getUserNotification,
  updateProfile,
  myBookings,
  MyOrders

} = require("../utils/Auth");
const { find } = require("../models/User");

router.get('/', (req, res) => {
  res.send("Calling user Route")
  console.log('Calling user Route')
})

// Users Registeration Route
router.post("/register-user", async (req, res) => {
  console.log("register")
  await userRegister(req.body, "user", res);
});

// Admin Registration Route
router.post("/register-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// Super Admin Registration Route
router.post("/register-super-admin", async (req, res) => {
  await userRegister(req.body, "superadmin", res);
});

// Users Login Route
router.post("/login-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin Login Route
router.post("/login-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});

// Super Admin Login Router


router.post("/login-super-admin", async (req, res) => {

  await userLogin(req.body, "superadmin", res);
});

// Profile Route
router.get("/profile", userAuth, async (req, res) => {
  return res.json(serializeUser(req.user));
});

// Users Protected Route
router.get(
  "/user-protectd",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    return res.json("Hello User");
  }
);

// Admin Protected Route
router.get(
  "/admin-protectd",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    return res.json("Hello Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-protectd",
  userAuth,
  checkRole(["superadmin"]),
  async (req, res) => {
    return res.json("Hello Super Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-and-admin-protectd",
  userAuth,
  checkRole(["superadmin", "admin"]),
  async (req, res) => {
    return res.json("Super admin and Admin");
  }
);



//geting all users
router.get('/getUserList', async (req, res) => {
  await getUserList(res)
})

router.post('/resetPassword', async (req, res) => {
  await resetPassword(req, res)

})

router.post("/verify", async (req, res) => {
  await verify(req, res);
});

// Change Password
router.post('/changePassword', async (req, res) => {
  await changePassword(req, res)
})

// router.post('/:id',async (req,res)=>{
//   console.log(req.params)
//   res.send('What the hell')
// })

// router.post('/changepass/:secret',(req,res)=>{
//   console.log(req.params)
//   console.log(req.body)
//   console.log(req.body.password)
//   console.log(req.body.confirmpassword)
//   if(req.body.password==req.body.confirmpassword){
//     res.send("Password Changed")
//   }
//   if(req.body.password!=req.body.confirmpassword){
//     res.send("Password Does Not Match")
//   }
// })
//--------------------------------------------Add To Cart

router.post('/usercart', async (req, res) => {

  await User.find({ email: req.body.email }, (err, docs) => {
    if (docs.length == 0) {
      res.status(200).json({
        message: "No User Found.",
        success: false
      });
    }
    if (docs.length > 0) {
      findProduct(req, res)
    }
    else {
      console.log(err)
      res.status(200).json({
        message: `Error:- ${err}`,
        success: flase
      });
    }
  })
  const newticket = new usercart()
})

const findProduct = (req, res) => {
  products.findOne({ _id: req.body._id }, (err, docs) => {
    if (!err) {
      userexistcreatecart(req, res, docs)
    }
    else {
      res.json({
        message: "No Product Found",
        success: false
      })
    }
  })
}

const userexistcreatecart = (req, res, data) => {
  console.log("present  1=" + req.body.email)
  usercart.find({ email: req.body.email }, (err, docs) => {
    //console.log(docs.length)
    if (docs.length == 0) {
      console.log("create new cart")
      createusercart(req, res, data);
    }
    if (docs.length > 0) {
      console.log("add to existing cart")
      //console.log("length 1 "  +docs)
      addtousercart(req, res, data)
    }
    else {
      console.log(err)
    }
  })
}



const createusercart = (req, res, data) => {
  console.log("present 0 11    " + req.body.quantity)
  const createNewCart = new usercart(
    {
      email: req.body.email,
      products: [{
        id: data._id,
        quantity: req.body.quantity,
        product_name: data.product_name,
        product_ld: data.product_ld,
        category: data.category,
        image: data.image,
        price: data.price,
        subTotal: data.sale_price * req.body.quantity,
        sale_price: data.sale_price,
        discount: data.discount

      }]
    })
  createNewCart.save((err) => {
    if (!err) {
      res.json({
        message: "Added To Your Cart.",
        success: true,
        data: 1
      })
    }
  })
}

var totalItemsInCart = (req) => {
  usercart.find({ email: req.body.email }, (err, docs) => {
    if (!err) {
      console.log(docs[0].products.length)
      return docs[0].products.length
    }
    else {
      console.log("Zero")
    }
  })
}

//---------------------------------------------------------
const addtousercart = (req, res, data) => {
  console.log("function call = " + totalItemsInCart(req))
  //console.log(data.products)
  //console.log("present add=" + req.body._id)
  //console.log(data[0].products[0]._id, data[0].products[0].product_name)
  //console.log(req.body._id == data[0].products[0].id)



  usercart.findOneAndUpdate({
    email: req.body.email
  }, {
    $push: {
      products: [{
        id: data._id,
        quantity: req.body.quantity,
        product_name: data.product_name,
        product_ld: data.product_ld,
        category: data.category,
        image: data.image,
        price: data.price,
        subTotal: data.sale_price * req.body.quantity,
        sale_price: data.sale_price,
        discount: data.discount
      }]
    }
  }, (err, docs) => {
    if (!err) {
      usercart.find({ email: req.body.email }, (err, docs) => {
        if (!err) {
          console.log(docs[0].products.length)

          res.json({
            message: "Successfully Added To Your Cart.",
            success: true,
            data: docs[0].products.length
          })
        }
        else {
          console.log("Zero")
        }
      })

    }
    else { console.log(err) }
  })




  //finding product 
  // for (let i = 0; i < data[0].products.length; i++) {
  //   if (data[0].products[i].id == req.body._id) {
  //     console.log("product already exist in cart")


  //     products.findById({ _id: req.body._id }, (err, docs) => {
  //       if (!err) {
  //         prod = docs
  //         usercart.findOneAndUpdate({
  //           email: req.body.email
  //         }, {
  //           $push: {
  //             products: [{
  //               id: docs._id,
  //               quantity: req.body.quntity,
  //               product_name: docs.product_name,
  //               product_ld: docs.product_ld,
  //               category: docs.category,
  //               image: docs.image,
  //               price: docs.price,
  //               subTotal: docs.price,
  //               sale_price:docs.sale_price,
  //               discount:docs.discount
  //             }]
  //           }
  //         }, (err, docs) => {
  //           if (!err) { res.sendStatus(200) }
  //           else (console.log(err))
  //         })
  //       }
  //     })



  //         // usercart.findOneAndUpdate({
  //         //   email: req.body.email,
  //         //   products:{$elemMatch: {product_name:"CBD Oil 1000ml"}}
  //         // }, {

  //         //     products: [{
  //         //       id: data._id,
  //         //       quantity: req.body.quntity,
  //         //       product_name: docs.product_name,
  //         //       product_ld: docs.product_ld,
  //         //       category: docs.category,
  //         //       image: docs.image,
  //         //       price: docs.price,
  //         //       subTotal: docs.price,
  //         //       sale_price:docs.sale_price,
  //         //       discount:docs.discount,
  //         //       subTotal: "1000"
  //         //     }]

  //         // }, (err, docs) => {
  //         //   if (!err) { res.sendStatus(200) }
  //         //   else (console.log(err))
  //         // })


  //     // usercart.find({products:{$elemMatch: { id: "609ccb3e6f061815ec3821f4"}} },(err,docs)=>{
  //     //   if(!err){
  //     //     console.log(docs)
  //     //   }
  //     //   else{
  //     //     console.log("i dont know"+err)
  //     //   }
  //     // })


  //     // usercart.findOneAndUpdate({email:req.body.email,products:[{id:req.body._id}]},{products:[{quantity:222}]},(err,docs)=>{
  //     //   console.log(docs)
  //     //   if(!err){
  //     //     console.log("added")
  //     //   }
  //     //   else{
  //     //     console.log(err)
  //     //   }
  //     // })
  //   }
  //   else {
  //     console.log("product add to cart")
  //     products.findById({ _id: req.body._id }, (err, docs) => {
  //       if (!err) {
  //         prod = docs
  //         usercart.findOneAndUpdate({
  //           email: req.body.email
  //         }, {
  //           $push: {
  //             products: [{
  //               id: docs._id,
  //               quantity: req.body.quntity,
  //               product_name: docs.product_name,
  //               product_ld: docs.product_ld,
  //               category: docs.category,
  //               image: docs.image,
  //               price: docs.price,
  //               subTotal: docs.price
  //             }]
  //           }
  //         }, (err, docs) => {
  //           if (!err) { res.sendStatus(200) }
  //           else (console.log(err))
  //         })
  //       }
  //     })
  //   }
  // }
  // //  products.findById({_id:req.body._id},(err,docs)=>{
  // //     if(!err){
  // //       prod=docs
  // //       usercart.findOneAndUpdate({
  // //         email: req.body.email
  // //       }, {
  // //         $push: {
  // //           products: [{
  // //             id:docs._id,
  // //             quantity:req.body.quntity,
  // //             product_name:docs.product_name,
  // //             product_ld:docs.product_ld,
  // //             category:docs.category,
  // //             image:docs.image,
  // //             price:docs.price,
  // //             subTotal:docs.price
  // //           }]
  // //         }
  // //       },(err,docs)=>{
  // //         if(!err){res.sendStatus(200)}
  // //         else(console.log(err))
  // //       })
  // //     }
  // //   })
}


//get user Cart
router.post('/getusercart', async (req, res) => {
  var total = 0
  await usercart.find({ email: req.body.email }, (err, docs) => {
    if (docs.length == 0) {
      res.json({
        message: "Your Cart is Empty",
        success: false,
      })
    }
    if (docs.length > 0) {

      for (let i = 0; i < docs[0].products.length; i++) {
        // 
        total = total + docs[0].products[i].subTotal
        console.log(total)
      }
      res.json({
        message: "Order Successfull",
        success: true,
        data: docs[0].products,
        MRP: total,
        totalDiscount: "400",
        deliveryCharge: "40"
      })
    }
    else {
      console.log(err)
    }
  })
})

router.post('/notification', async (req, res) => {
  await notifications(req, res)
})

router.post('/getUserNotification', async (req, res) => {
  await getUserNotification(req, res)
})

router.post('/updateProfile', async (req, res) => {
  await updateProfile(req, res)
})

router.post('/addMyOrders', async (req, res) => {
  await myBookings(req, res)
})


router.post('/MyOrders', async (req, res) => {
  await MyOrders(req, res)
})

router.post('/deletCart', (req, res) => {
  usercart.findOneAndDelete({ email: req.body.email }, (err, docs) => {
    if (!err) {
      console.log("deleted")
      res.send("Delete Successfull")
    }
    else {
      console.log(err)
      res.send("Delete UnSuccessfull")
    }
  })
})

// const getProductLatestPrice = async id => {

//   let productPrise = await products.findOne({ _id:id },(err,docs)=>{
//     if(!err){
//       return docs.price
//     }
//   else{
//     return 678
//   }
//   });
// };

const getProductLatestPrice = async id => {
  let productPrise = await products.findOne({ _id: id });
  return productPrise;
};

const getUserCart = async (email, id) => {
  let uc = await usercart.findOne({ email: email });
  for (let i = 0; i < uc.products.length; i++) {
    if (uc.products[i].id == id) {
      return uc.products[i];
    }
  }


};

router.post('/updateQuantity', async (req, res) => {
  let pp = await getProductLatestPrice(req.body.pid)
  let uc = await getUserCart(req.body.email, req.body.pid)
  usercart.findOneAndUpdate(
    { email: req.body.email },
    {
      $set: {
        "products.$[el].quantity": req.body.quantity,
        "products.$[el].subTotal": pp.sale_price * req.body.quantity,
        "products.$[el].sale_price": pp.sale_price,
        "products.$[el].price": pp.price,
        "products.$[el].discount": pp.discount

      }
    },
    {
      arrayFilters: [{ "el.quantity": uc.quantity }],
      new: true
    }, (docs, err) => {
      res.json({
        message: "Quantity Increased",
        success: true
      })
    }
  )

})

router.post('/deletCartItem',async (req, res) => {
  //usercart.f
  //usercart.update({ _id: diveId },{"$pull": { "drivers": {"user": "123456789"}}})
  await usercart.findOneAndUpdate( // select your doc in moongo
    { email: req.body.email }, // your query, usually match by _id
    { $pull: { "products.$[el].id": {  id: '60a78a0b2cc7e50ae495d052'} } }, // item(s) to match from array you want to pull/remove
    { 
      multi: true ,
      arrayFilters: [{ "el.id": '60a78a0b2cc7e50ae495d052' }],
      new: true
    }, // set this to true if you want to remove multiple elements.

    (err, docs) => {
      if (!err) {
        console.log("docs")
      }
      else {
        console.log(err)
      }
    }
  )
})

module.exports = router;




const { Schema, model } = require("mongoose");

const banner = new Schema(
  {
    banner: {
      type: String,
      required: true
    }
  }
);

module.exports = model("banner", banner);

const router = require("express").Router();
const User = require("../models/User");
const usercart= require("../models/usercart");
const products=require("../models/products")
const cors = require("cors");

// Bring in the User Registration function
const {
  userAuth,
  userLogin,
  checkRole,
  userRegister,
  serializeUser,
  getUserList,
  resetPassword,
  verify,
  changePassword,
  forgetPassword

} = require("../utils/Auth");

router.get('/',(req,res)=>{
  res.send("Calling user Route")
  console.log('Calling user Route')
})

// Users Registeration Route
router.post("/register-user", async (req, res) => {
  console.log("register")
  await userRegister(req.body, "user", res);
});

// Admin Registration Route
router.post("/register-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// Super Admin Registration Route
router.post("/register-super-admin", async (req, res) => {
  await userRegister(req.body, "superadmin", res);
});

// Users Login Route
router.post("/login-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin Login Route
router.post("/login-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});

// Super Admin Login Router


router.post("/login-super-admin", async (req, res) => {
  
  await userLogin(req.body, "superadmin", res);
});

// Profile Route
router.get("/profile", userAuth, async (req, res) => {
  return res.json(serializeUser(req.user));
});

// Users Protected Route
router.get(
  "/user-protectd",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    return res.json("Hello User");
  }
);

// Admin Protected Route
router.get(
  "/admin-protectd",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    return res.json("Hello Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-protectd",
  userAuth,
  checkRole(["superadmin"]),
  async (req, res) => {
    return res.json("Hello Super Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-and-admin-protectd",
  userAuth,
  checkRole(["superadmin", "admin"]),
  async (req, res) => {
    return res.json("Super admin and Admin");
  }
);



//geting all users
router.get('/getUserList',async (req,res)=>{
  await getUserList(res)
})

router.post('/resetPassword',async (req,res)=>{
  await resetPassword(req,res)

})

router.post("/verify", async (req, res) => {
  await verify(req, res);
});

// Change Password
router.post('/changePassword', async (req, res) => {
  await changePassword(req, res)
})

// router.post('/:id',async (req,res)=>{
//   console.log(req.params)
//   res.send('What the hell')
// })

// router.post('/changepass/:secret',(req,res)=>{
//   console.log(req.params)
//   console.log(req.body)
//   console.log(req.body.password)
//   console.log(req.body.confirmpassword)
//   if(req.body.password==req.body.confirmpassword){
//     res.send("Password Changed")
//   }
//   if(req.body.password!=req.body.confirmpassword){
//     res.send("Password Does Not Match")
//   }
// })
//--------------------------------------------Add To Cart
router.post('/usercart', async (req, res) => {
  console.log("cart")
  await User.find({ email: req.body.email }, (err, docs) => {
    if (docs.length==0) {
      res.status(200).json({
        message: "No User Found.",
        success: false
      });
    }
    if (docs.length>0) {
      userexistcreatecart(req,res)
    }
    else {
      console.log(err)
      res.status(200).json({
        message: `Error:- ${err}`,
        success: flase
      });
    }
  })
  const newticket= new usercart()
})


const userexistcreatecart=(req,res)=>{
  console.log("present  1=" +req.body.email)
  usercart.find({ email: req.body.email }, (err, docs) => {
    //console.log(docs.length)
    if (docs.length==0) {
      console.log("create new cart")
      createusercart(req, res);
    }
    if (docs.length>0) {
      console.log("add to existing cart")
      //console.log("length 1 "  +docs)
      addtousercart(req, res,docs)
    }
    else { 
      console.log(err)
    }
  })
}


const createusercart = (req, res) => {
  console.log("present 0 11    " +req.body)
  products.findById({_id:req.body._id},(err,docs)=>{
    console.log(docs)
    if(!err){
      const createNewCart = new usercart(
        {
        email:req.body.email,
        products:[req.body.quntity,[docs]]
      }, (err, docs) => {
        if (!err) { console.log(docs) }
        else { console.log(err) }
      })
      createNewCart.save(res.sendStatus(200))
    }
  })

}

const addtousercart = (req, res,data) => {
  console.log("present add=" + req.body.email,data[0].products)
  //finding product 
 let prod={}
  
//  products.findById({_id:req.body._id},(err,docs)=>{
//     if(!err){
//       prod=docs
//       usercart.findOneAndUpdate({
//         email: req.body.email
//       }, {
//         $push: {
//           products: [docs]
//         }
//       },(err,docs)=>{
//         if(!err){res.sendStatus(200)}
//         else(console.log(err))
//       })
//     }
//   })
}

//get user Cart
router.get('/getusercart', async (req, res) => {
  await usercart.find({email:req.body.email},(err,docs)=>{
    if(docs.length==0){
      res.send("user not found")
    }
    if(docs.length>0){
      res.send(docs)
    }
    else{
      console.log(err)
    }
  })

})




module.exports = router;




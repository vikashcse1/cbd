// Event create
// -Title of event
// -category from the list
// -choose promoters from the list
// -upcoming events (schedule date and time)
// -Ticket value
// -upload banner for thumbnail


const { Schema, model } = require("mongoose");

const resetPass = new Schema(
  {
    email:{
        type: String,
        required: true  
    },
    otp:{
        type:Number,
        require:true
    }
  },
  { timestamps: true }
);

module.exports = model("resetPass", resetPass);

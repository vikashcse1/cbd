const { Schema, model } = require("mongoose");

const UserSchema = new Schema(
  {
    profile_pic:{
      type:String
    },
    email: {
      type: String,
      required: true
    },
    role: {
      type: String,
      default: "user",
      enum: ["user", "admin", "superadmin"]
    },
    name: {
      type: String,
      required: true
    },
    password: {
      type: String,
      required: true
    },
    phone:{
      type:Number,
      require:true
    },
    address:[]
  },
  { timestamps: true }
);

module.exports = model("users", UserSchema);

const { Schema, model } = require("mongoose");

const aboutus = new Schema(
  {
    title: {
      type: String
    },
    info:{
        type: String
    }
  }
);

module.exports = model("aboutus", aboutus);

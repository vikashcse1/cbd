const category=require("../models/category")


/**
 * @DESC To Insert Product
 */
 const insert_category = async (userDets, res) => {
    try {
      // create a new user
      const newCategory = new category({
        ...userDets,
      });
  
      await newCategory.save();
      return res.status(201).json({
        message: "Successfully Added The New Category",
        success: true
      });
    } catch (err) {
      // Implement logger function (winston)
      return res.status(200).json({
        message: "Unable to create Category.",
        success: false
      });
    }
  };

  const get_category= async (data,res)=>{
    all = await category.find({"category_name":data},(err, docs) => {
      if (!err) {
        res.send(docs);
        return docs;
        console.log(docs);
      }
      else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
    //console.log(all)
  };

  const delete_category =  async(req,res)=>{
     await category.findByIdAndDelete({_id:req.body._id},(err,docs)=>{
      if(!err){
        //console.log(docs)
        res.status(200).json({
          message: "Category Deleted.",
          success: true
        });
      }
      else{
        console.log(err)
        res.status(200).json({
          message: `${err}`,
          success: false
        });
      }
    })
  }


  module.exports = {
    insert_category,
    get_category,
    delete_category
};
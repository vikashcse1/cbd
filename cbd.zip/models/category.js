const { Schema, model } = require("mongoose");

const category = new Schema(
  {
    categoryName: {
      type: String,
      required: true
    },
    parent: {
      type: String,
      required: true
    },
    categoryDescription: {
      type: String,
      required: true
    },
    sortOrder: {
      type: Number,
    },

    
    categoryImage: {
      type: String,
      required: true
    },
    status:{
      type: String,
      required: true
    }
  },
  { timestamps: true }
);

module.exports = model("category", category);

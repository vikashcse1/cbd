const router = require("express").Router();
const category = require("../models/category");
const cors = require("cors");
const multer = require('multer');


//storage startegy
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
});
//file filter
const fileFilter = (req, file, cb) => {
    //reject file
    if (file.mimetype === 'image/jpg' ||file.mimetype === 'image/jpeg'||file.mimetype === 'image/png') {
        cb(null, true);
    } 
    else{
    cb(new Error('Message wrong file type.'), false);
    }
}

const upload = multer({ 
    storage: storage ,
    fileFilter:fileFilter
});

const {
    insert_category,
    get_category
} = require("../utils/category");

router.post("/insert_category", upload.single('categoryImage'),async (req, res, next) => {
    console.log(req.body)
    console.log(req.file)
    await insert_category(req.body,res);
    res.status(202)
});


router.get("/get_category",async(req,res,next)=>{
    let cat=req.body.category_name
    await get_category(cat,res)
})

module.exports = router;
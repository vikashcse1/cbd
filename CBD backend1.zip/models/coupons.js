const { Schema, model } = require("mongoose");

const coupons = new Schema(
    {
        phone: {
            type: String,
            required: true
        },
        couponCode: {
            type: String,
            required: true
        },
        expire:{type:Date}
    }
);

module.exports = model("coupons", coupons);

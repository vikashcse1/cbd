const { Schema, model } = require("mongoose");

const faq = new Schema(
  {
    question: {
      type: String
    },
    answer:{
        type: String
    }
  }
);

module.exports = model("faq", faq);
